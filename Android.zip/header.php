<div class="menu header">

<ul>

	<li style="float:left; padding-left: 3px;"><img src="/images/header.png" width='95px'/></li>
	<div class="ac">
	
    <li style="padding-top:0px;"><a href="?cont=exit"><img src="/images/exit.png" width='50px'/></a></li>
	<li><a href="?cont=commands">Команды</a></li>
	<li><a href="?cont=maps">Карта</a></li>
	<li><a href="?cont=injections">База инжектов</a></li>
	<li><a href="?cont=grabingcc">База карт</a></li>
	<li><a href="?cont=dump_numbers">База номеров</a></li>
	<li><a href="?cont=statistic">Статистика</a></li>  
	<li><a href="?cont=kliets&page=1">Боты</a></li> 
	</div>
	<li style="padding-top:0px;"><a><img src="/images/not.png" width='0px' height='50px'/></a></li>

	 
</ul>
</div>