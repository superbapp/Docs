<?php
define('SERVER' , 'localhost');
define('DB', 'database');
define('USER', 'root');
define('PASSWORD' , '350638');
define('cryptKey' , 'qwe');//ключ шифрования трафика!
